import React from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, { Easing } from "react-native-reanimated";
import { runTiming } from "react-native-redash";

import CircularProgress from "./components/CircularProgress2";

const { Clock } = Animated;

export default () => {
  const clock = new Clock();
  const config = {
    duration: 10 * 1000,
    toValue: 1,
    easing: Easing.linear,
  };
  return (
    <View style={styles.container}>
    <View style = {styles.header}>
    <Text style={styles.boldText}>Diet</Text>
    </View>
    <View>
      <Text style={styles.centerText}>Veg</Text>
    </View>
      <CircularProgress progress={runTiming(clock, 5, config)} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    alignItems: 'center',
    
  },
  boldText: {
    fontWeight: 'bold',
    fontSize: 30,
    fontFamily: 'Helvetica',
  },
  centerText: {
    fontSize: 30,
    fontFamily: 'Helvetica-Bold',
    paddingRight: 50,
    paddingTop: 100,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    flex: 1,
  },
});
